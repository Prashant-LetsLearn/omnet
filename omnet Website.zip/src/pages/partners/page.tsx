import { useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../home/components/Navbar';
import Footer from '../home/components/Footer';

export default function PartnersPage() {
  const [openCategory, setOpenCategory] = useState<string | null>(null);

  const toggleCategory = (category: string) => {
    setOpenCategory(openCategory === category ? null : category);
  };

  const partnerCategories = [
    {
      id: 'microsoft',
      name: 'Microsoft',
      icon: 'ri-microsoft-fill',
      color: 'bg-blue-500',
      products: [
        'Microsoft 365',
        'Windows Server',
        'Azure Cloud Services',
        'SQL Server',
        'Dynamics 365',
        'Power Platform',
        'Microsoft Teams',
        'SharePoint',
        'Exchange Server',
        'Visual Studio'
      ]
    },
    {
      id: 'google',
      name: 'Google',
      icon: 'ri-google-fill',
      color: 'bg-green-500',
      products: [
        'Google Workspace',
        'Google Cloud Platform (GCP)',
        'Google Drive',
        'Gmail Business',
        'Google Meet',
        'Google Calendar',
        'Google Docs & Sheets',
        'Google Cloud Storage',
        'Google Kubernetes Engine',
        'BigQuery Analytics'
      ]
    },
    {
      id: 'adobe',
      name: 'Adobe',
      icon: 'ri-adobe-fill',
      color: 'bg-red-500',
      products: [
        'Adobe Creative Cloud',
        'Photoshop',
        'Illustrator',
        'InDesign',
        'Premiere Pro',
        'After Effects',
        'Adobe Acrobat Pro',
        'Adobe XD',
        'Lightroom',
        'Adobe Sign'
      ]
    },
    {
      id: 'autodesk',
      name: 'Autodesk',
      icon: 'ri-building-line',
      color: 'bg-teal-600',
      products: [
        'AutoCAD',
        'Revit',
        '3ds Max',
        'Maya',
        'Fusion 360',
        'Inventor',
        'Civil 3D',
        'AutoCAD LT',
        'BIM 360',
        'Navisworks'
      ]
    },
    {
      id: 'cloud',
      name: 'Cloud Solutions',
      icon: 'ri-cloud-line',
      color: 'bg-sky-500',
      products: [
        'Amazon Web Services (AWS)',
        'Microsoft Azure',
        'Google Cloud Platform',
        'IBM Cloud',
        'Oracle Cloud',
        'Salesforce Cloud',
        'VMware Cloud',
        'Dropbox Business',
        'Box Enterprise',
        'Cloud Backup Solutions'
      ]
    },
    {
      id: 'software',
      name: 'Software Solutions',
      icon: 'ri-code-box-line',
      color: 'bg-purple-500',
      products: [
        'Enterprise Resource Planning (ERP)',
        'Customer Relationship Management (CRM)',
        'Project Management Tools',
        'Accounting Software',
        'HR Management Systems',
        'Business Intelligence Tools',
        'Collaboration Software',
        'Security Software',
        'Database Management',
        'Development Tools'
      ]
    },
    {
      id: 'hardware',
      name: 'Hardware Solutions',
      icon: 'ri-computer-line',
      color: 'bg-gray-700',
      products: [
        'Dell Servers & Workstations',
        'HP Enterprise Solutions',
        'Lenovo Business Systems',
        'Cisco Networking Equipment',
        'Storage Solutions',
        'Backup Systems',
        'Printers & Scanners',
        'Security Cameras',
        'Access Control Systems',
        'UPS & Power Solutions'
      ]
    },
    {
      id: 'digital-marketing',
      name: 'Digital Marketing',
      icon: 'ri-megaphone-line',
      color: 'bg-pink-500',
      products: [
        'Search Engine Optimization (SEO)',
        'Pay-Per-Click Advertising (PPC)',
        'Social Media Marketing',
        'Content Marketing',
        'Email Marketing Campaigns',
        'Marketing Automation',
        'Google Ads Management',
        'Facebook & Instagram Ads',
        'Analytics & Reporting',
        'Brand Strategy & Design'
      ]
    },
    {
      id: 'managed-it',
      name: 'Managed IT Services',
      icon: 'ri-settings-3-line',
      color: 'bg-orange-500',
      products: [
        '24/7 IT Support',
        'Network Monitoring',
        'Cloud Management',
        'Data Backup & Recovery',
        'Cybersecurity Services',
        'IT Consulting',
        'System Maintenance',
        'Help Desk Support',
        'Infrastructure Management',
        'Disaster Recovery Planning'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-teal-50 to-white">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Our Technology Partners
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            We collaborate with industry-leading technology providers to deliver cutting-edge solutions 
            that drive your business forward. Explore our comprehensive range of products and services.
          </p>
        </div>
      </section>

      {/* Partners Grid */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {partnerCategories.map((category) => (
              <div
                key={category.id}
                className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:shadow-xl transition-all duration-300"
              >
                {/* Category Header */}
                <button
                  onClick={() => toggleCategory(category.id)}
                  className="w-full p-6 flex items-center justify-between cursor-pointer hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <div className={`w-12 h-12 ${category.color} rounded-lg flex items-center justify-center`}>
                      <i className={`${category.icon} text-white text-2xl`}></i>
                    </div>
                    <h3 className="text-xl font-bold text-gray-900">{category.name}</h3>
                  </div>
                  <i className={`ri-arrow-${openCategory === category.id ? 'up' : 'down'}-s-line text-2xl text-gray-400 transition-transform`}></i>
                </button>

                {/* Dropdown Content */}
                <div
                  className={`overflow-hidden transition-all duration-300 ${
                    openCategory === category.id ? 'max-h-[600px]' : 'max-h-0'
                  }`}
                >
                  <div className="px-6 pb-6 border-t border-gray-100">
                    <ul className="space-y-3 mt-4">
                      {category.products.map((product, index) => (
                        <li
                          key={index}
                          className="flex items-start space-x-3 text-gray-700 hover:text-teal-500 transition-colors cursor-pointer"
                        >
                          <i className="ri-check-line text-teal-500 text-lg mt-0.5 flex-shrink-0"></i>
                          <span className="text-sm">{product}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Partner With Us */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Partner With Us?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We bring together the best technology solutions to meet your business needs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-shield-check-line text-3xl text-teal-500"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Certified Experts</h3>
              <p className="text-sm text-gray-600">
                Our team holds certifications from all major technology partners
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-customer-service-2-line text-3xl text-teal-500"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">24/7 Support</h3>
              <p className="text-sm text-gray-600">
                Round-the-clock assistance for all your technology needs
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-price-tag-3-line text-3xl text-teal-500"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Best Pricing</h3>
              <p className="text-sm text-gray-600">
                Competitive rates with flexible licensing options
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-rocket-line text-3xl text-teal-500"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Fast Deployment</h3>
              <p className="text-sm text-gray-600">
                Quick implementation and seamless integration
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-teal-500 to-teal-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-lg text-teal-50 mb-8">
            Let us help you find the perfect technology solution for your business
          </p>
          <Link
            to="/contact"
            className="inline-block px-8 py-3 bg-white text-teal-500 rounded-full font-semibold hover:bg-gray-100 transition-all shadow-lg whitespace-nowrap"
          >
            Contact Our Team
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
