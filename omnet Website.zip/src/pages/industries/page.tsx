import { useEffect } from 'react';
import Navbar from '../home/components/Navbar';
import Footer from '../home/components/Footer';

export default function IndustriesPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const industries = [
    {
      icon: 'ri-computer-line',
      title: 'IT/ITES',
      description: 'Comprehensive IT solutions and services for digital transformation and business growth.'
    },
    {
      icon: 'ri-shopping-cart-line',
      title: 'Retail',
      description: 'Point-of-sale systems, inventory management, and customer engagement solutions.'
    },
    {
      icon: 'ri-heart-pulse-line',
      title: 'Healthcare',
      description: 'HIPAA-compliant systems, patient management, and healthcare analytics solutions.'
    },
    {
      icon: 'ri-building-line',
      title: 'Manufacturing',
      description: 'ERP systems, supply chain management, and production optimization tools.'
    },
    {
      icon: 'ri-bank-line',
      title: 'Banking & Finance',
      description: 'Secure financial systems, payment processing, and compliance management.'
    },
    {
      icon: 'ri-graduation-cap-line',
      title: 'Education',
      description: 'Learning management systems, student portals, and educational technology.'
    },
    {
      icon: 'ri-hotel-line',
      title: 'Hospitality',
      description: 'Booking systems, property management, and guest experience solutions.'
    },
    {
      icon: 'ri-truck-line',
      title: 'Logistics',
      description: 'Fleet management, route optimization, and real-time tracking systems.'
    },
    {
      icon: 'ri-shopping-bag-line',
      title: 'Consumer Packaged Goods',
      description: 'Supply chain optimization, demand forecasting, and distribution management.'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* Hero Section with Diagonal Background */}
      <section className="relative pt-32 pb-24 overflow-hidden bg-gradient-to-br from-teal-600 via-teal-700 to-teal-800">
        {/* Diagonal Geometric Shape */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -right-1/4 -top-1/4 w-3/4 h-full bg-gradient-to-br from-teal-400/20 to-teal-600/20 transform rotate-12"></div>
          <div className="absolute -left-1/4 -bottom-1/4 w-3/4 h-full bg-gradient-to-tr from-teal-800/30 to-teal-500/30 transform -rotate-12"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-6">
          <div className="max-w-3xl">
            <div className="inline-block px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full mb-6">
              <span className="text-white font-semibold text-sm">OUR EXPERTISE</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Technology Is <span className="text-yellow-300">Transforming</span><br />
              Every Industry Sector
            </h1>
            <p className="text-xl text-white/90 leading-relaxed mb-8">
              We deliver tailored IT solutions across diverse industries, helping businesses leverage technology for growth, efficiency, and competitive advantage.
            </p>
          </div>
        </div>
      </section>

      {/* Industries We Serve Section */}
      <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <div className="inline-block px-4 py-2 bg-teal-100 rounded-full mb-4">
              <span className="text-teal-700 font-semibold text-sm">INDUSTRY SOLUTIONS</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              We Serve A Wide <span className="text-teal-600">Variety</span><br />
              Of Industries
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              From healthcare to manufacturing, we provide specialized IT solutions that address the unique challenges of each industry sector.
            </p>
          </div>

          {/* Industries Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {industries.map((industry, index) => (
              <div 
                key={index}
                className="group bg-white p-8 rounded-2xl border-2 border-gray-100 hover:border-teal-400 hover:shadow-2xl transition-all duration-300 cursor-pointer"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-teal-500 to-teal-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-3 transition-all duration-300">
                  <i className={`${industry.icon} text-white text-3xl`}></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-teal-600 transition-colors">
                  {industry.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {industry.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-block px-4 py-2 bg-teal-100 rounded-full mb-4">
                <span className="text-teal-700 font-semibold text-sm">WHY CHOOSE US</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                Choose <span className="text-teal-600">The Best</span> IT<br />
                Service Company
              </h2>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                With years of experience across multiple industries, we understand the unique challenges and opportunities in each sector. Our team delivers customized solutions that drive real business results.
              </p>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-shield-check-line text-teal-600 text-xl"></i>
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">Industry Expertise</h4>
                    <p className="text-gray-600">Deep understanding of sector-specific challenges and compliance requirements.</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-customer-service-2-line text-teal-600 text-xl"></i>
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">24/7 Technical Support</h4>
                    <p className="text-gray-600">Round-the-clock support to keep your business running smoothly.</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <i className="ri-line-chart-line text-teal-600 text-xl"></i>
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-gray-900 mb-2">Proven Track Record</h4>
                    <p className="text-gray-600">Successfully delivered 500+ projects across various industries.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <img 
                  src="https://readdy.ai/api/search-image?query=professional%20business%20team%20collaborating%20on%20technology%20solutions%20in%20modern%20office%20environment%20with%20laptops%20and%20digital%20screens%20showing%20data%20analytics%20and%20business%20intelligence%20dashboards%2C%20bright%20natural%20lighting%2C%20corporate%20setting%2C%20diverse%20team%20members%20working%20together&width=600&height=700&seq=industries-team-collab&orientation=portrait"
                  alt="Professional IT Team"
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Decorative dots */}
              <div className="absolute -bottom-6 -right-6 w-32 h-32 grid grid-cols-4 gap-2 opacity-30">
                {[...Array(16)].map((_, i) => (
                  <div key={i} className="w-2 h-2 bg-teal-500 rounded-full"></div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-20 bg-gradient-to-r from-teal-600 via-teal-700 to-teal-800">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-5xl font-bold text-white mb-2">20+</div>
              <div className="text-xl text-white/90">Years Experience</div>
            </div>
            <div>
              <div className="text-5xl font-bold text-white mb-2">2.5k+</div>
              <div className="text-xl text-white/90">Happy Clients</div>
            </div>
            <div>
              <div className="text-5xl font-bold text-white mb-2">76+</div>
              <div className="text-xl text-white/90">Expert Team</div>
            </div>
            <div>
              <div className="text-5xl font-bold text-white mb-2">4.9/5</div>
              <div className="text-xl text-white/90">Client Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Ready To Transform Your<br />
            <span className="text-teal-600">Industry With Technology?</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            Let's discuss how our industry-specific solutions can help your business achieve its goals.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="/contact" 
              className="inline-flex items-center justify-center px-8 py-4 bg-teal-600 text-white font-semibold rounded-xl hover:bg-teal-700 transition-colors whitespace-nowrap cursor-pointer"
            >
              Get Started
              <i className="ri-arrow-right-line ml-2"></i>
            </a>
            <a 
              href="/services" 
              className="inline-flex items-center justify-center px-8 py-4 bg-white text-teal-600 font-semibold rounded-xl border-2 border-teal-600 hover:bg-teal-50 transition-colors whitespace-nowrap cursor-pointer"
            >
              View Our Services
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
