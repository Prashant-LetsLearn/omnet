import { useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../home/components/Navbar';
import Footer from '../home/components/Footer';

export default function ServicesPage() {
  const [expandedService, setExpandedService] = useState<number | null>(null);

  const services = [
    {
      id: 1,
      icon: 'ri-cloud-line',
      title: 'Cloud Solutions',
      description: 'AWS, Azure, GCP migration & management, hybrid & multi-cloud architecture, cloud security, governance & compliance.',
      features: ['Cloud Migration', 'Multi-Cloud', 'Security & Compliance', 'Cost Optimization'],
      bgColor: 'from-blue-50 to-white',
      color: 'from-blue-500 to-blue-600'
    },
    {
      id: 2,
      icon: 'ri-database-2-line',
      title: 'Data Management',
      description: 'Enterprise data warehousing, data migration & lake modernization, governance, security & compliance, analytics & BI.',
      features: ['Data Warehousing', 'Migration', 'Governance', 'Analytics & BI'],
      bgColor: 'from-purple-50 to-white',
      color: 'from-purple-500 to-purple-600'
    },
    {
      id: 3,
      icon: 'ri-computer-line',
      title: 'Digital Workplace',
      description: 'Google Workspace & Microsoft 365, endpoint & device management, workflow automation & collaboration tools.',
      features: ['M365 & Workspace', 'Device Management', 'Automation', 'User Training'],
      bgColor: 'from-teal-50 to-white',
      color: 'from-teal-500 to-teal-600'
    },
    {
      id: 4,
      icon: 'ri-code-s-slash-line',
      title: 'Application Development',
      description: 'Custom web & mobile applications, DevOps & automation, application modernization, performance & security optimization.',
      features: ['Custom Apps', 'DevOps', 'Modernization', 'Optimization'],
      bgColor: 'from-orange-50 to-white',
      color: 'from-orange-500 to-orange-600'
    },
    {
      id: 5,
      icon: 'ri-server-line',
      title: 'Infrastructure Management',
      description: 'Windows Server & virtualization, network administration, backup, DR & business continuity, capacity planning.',
      features: ['Server Management', 'Networking', 'Backup & DR', 'Monitoring'],
      bgColor: 'from-green-50 to-white',
      color: 'from-green-500 to-green-600'
    },
    {
      id: 6,
      icon: 'ri-shield-check-line',
      title: 'Cybersecurity',
      description: 'Endpoint protection, threat detection & response, security policy design, vulnerability management & compliance support.',
      features: ['Endpoint Security', 'Threat Detection', 'Compliance', 'Security Audits'],
      bgColor: 'from-red-50 to-white',
      color: 'from-red-500 to-red-600'
    },
    {
      id: 7,
      icon: 'ri-customer-service-2-line',
      title: 'Support',
      description: 'Cloud, Network, Endpoint & IT Governance support with industry-leading platforms and comprehensive management solutions.',
      features: ['JumpCloud', 'M/O365', 'Google Workspace', 'Entra', 'Intune', 'Jamf', 'Fortinet', 'CrowdStrike', 'SAP'],
      bgColor: 'from-pink-50 to-white',
      color: 'from-pink-500 to-pink-600'
    },
    {
      id: 8,
      icon: 'ri-line-chart-line',
      title: 'IT Consulting',
      description: 'Strategic technology planning, digital transformation roadmaps, vendor selection & evaluation, IT governance frameworks.',
      features: ['Strategy Planning', 'Digital Transform', 'Vendor Selection', 'IT Governance'],
      bgColor: 'from-indigo-50 to-white',
      color: 'from-indigo-500 to-indigo-600'
    },
    {
      id: 9,
      icon: 'ri-tools-line',
      title: 'Technical Support',
      description: 'L1–L3 helpdesk support, computer repair, networking solutions, home networking & data recovery services.',
      features: ['Helpdesk L1-L3', 'Computer Repair', 'Networking', 'Data Recovery'],
      bgColor: 'from-yellow-50 to-white',
      color: 'from-yellow-500 to-yellow-600'
    }
  ];

  const toggleService = (id: number) => {
    setExpandedService(expandedService === id ? null : id);
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-teal-500 via-blue-500 to-purple-600"></div>
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
              Comprehensive IT Services
            </h1>
            <p className="text-xl text-white/90 leading-relaxed">
              End-to-end technology solutions designed to accelerate your digital transformation journey and drive business growth
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service) => (
              <div
                key={service.id}
                className="bg-white rounded-2xl border-2 border-gray-100 hover:border-teal-200 transition-all duration-300 overflow-hidden group"
              >
                <div
                  className={`p-8 bg-gradient-to-br ${service.bgColor} cursor-pointer`}
                  onClick={() => toggleService(service.id)}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-xl flex items-center justify-center shadow-lg`}>
                      <i className={`${service.icon} text-white text-3xl`}></i>
                    </div>
                    <button
                      className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-md hover:shadow-lg transition-all"
                      aria-label={expandedService === service.id ? 'Collapse' : 'Expand'}
                    >
                      <i className={`ri-arrow-${expandedService === service.id ? 'up' : 'down'}-s-line text-gray-700 text-xl`}></i>
                    </button>
                  </div>
                  
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">
                    {service.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {service.description}
                  </p>
                </div>

                {expandedService === service.id && (
                  <div className="p-8 bg-white border-t-2 border-gray-100">
                    <h4 className="text-lg font-bold text-gray-900 mb-4">Key Features:</h4>
                    <ul className="grid grid-cols-1 gap-3">
                      {service.features.map((feature, index) => (
                        <li key={index} className="flex items-start">
                          <i className="ri-checkbox-circle-fill text-teal-500 text-xl mr-3 mt-0.5"></i>
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Our Services */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose Our Services?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We deliver exceptional IT services backed by expertise, innovation, and commitment to your success
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-teal-500 to-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <i className="ri-team-line text-white text-4xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Expert Team</h3>
              <p className="text-gray-600">
                Certified professionals with deep industry expertise and technical knowledge
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <i className="ri-time-line text-white text-4xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">24×7 Support</h3>
              <p className="text-gray-600">
                Round-the-clock monitoring and support to ensure business continuity
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <i className="ri-rocket-line text-white text-4xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Innovation Focus</h3>
              <p className="text-gray-600">
                Leveraging latest technologies to deliver cutting-edge solutions
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-teal-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <i className="ri-shield-check-line text-white text-4xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Security First</h3>
              <p className="text-gray-600">
                Enterprise-grade security measures to protect your critical assets
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-teal-500 via-blue-500 to-purple-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Transform Your IT Infrastructure?
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Let's discuss how our services can help you achieve your business goals
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center px-8 py-4 bg-white text-teal-600 font-semibold rounded-lg hover:bg-gray-50 transition-all shadow-xl hover:shadow-2xl whitespace-nowrap"
          >
            <i className="ri-message-3-line mr-2 text-xl"></i>
            Contact Our Team
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
