import Navbar from '../home/components/Navbar';
import Footer from '../home/components/Footer';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-teal-500 via-teal-600 to-blue-600 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/10 to-black/20"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
              About <span className="text-teal-100">OMNET IT SYSTEM</span>
            </h1>
            <p className="text-xl text-white/90 leading-relaxed">
              Your trusted partner in digital transformation, delivering innovative IT solutions and 24×7 managed services to businesses across India since our inception.
            </p>
          </div>
        </div>
      </section>

      {/* Company Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Building the Foundation of <span className="text-teal-500">Digital Excellence</span>
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                OMNET IT SYSTEM is a leading IT services provider based in Ghaziabad, India, specializing in comprehensive technology solutions that empower businesses to thrive in the digital age.
              </p>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                We combine deep technical expertise with industry knowledge to deliver tailored solutions across cloud computing, cybersecurity, infrastructure management, and digital workplace services.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                Our commitment to excellence and 24×7 support ensures that your business operations run smoothly, securely, and efficiently at all times.
              </p>
            </div>
            <div className="relative">
              <img
                src="https://readdy.ai/api/search-image?query=modern%20professional%20IT%20office%20workspace%20with%20diverse%20team%20of%20technology%20professionals%20collaborating%20on%20digital%20solutions%2C%20computers%20and%20monitors%20displaying%20data%20analytics%2C%20bright%20and%20innovative%20corporate%20environment%20with%20glass%20walls%20and%20modern%20furniture&width=600&height=700&seq=about-office-1&orientation=portrait"
                alt="OMNET IT SYSTEM Office"
                className="rounded-2xl shadow-2xl w-full h-full object-cover object-top"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="bg-white p-10 rounded-2xl shadow-xl border border-gray-100">
              <div className="w-16 h-16 bg-gradient-to-br from-teal-500 to-blue-500 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-rocket-line text-white text-3xl"></i>
              </div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Our Mission</h3>
              <p className="text-lg text-gray-600 leading-relaxed">
                To empower businesses with innovative IT solutions that drive growth, enhance efficiency, and ensure security. We strive to be the trusted technology partner that enables our clients to focus on their core business while we handle their IT infrastructure with excellence.
              </p>
            </div>

            <div className="bg-white p-10 rounded-2xl shadow-xl border border-gray-100">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-eye-line text-white text-3xl"></i>
              </div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">Our Vision</h3>
              <p className="text-lg text-gray-600 leading-relaxed">
                To become India's most trusted IT services provider, recognized for our commitment to innovation, reliability, and customer success. We envision a future where every business, regardless of size, has access to enterprise-grade IT solutions and support.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Our Core <span className="text-teal-500">Values</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              The principles that guide everything we do and define who we are as a company
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-gradient-to-br from-teal-50 to-white p-8 rounded-2xl border border-teal-100 hover:shadow-xl transition-all">
              <div className="w-14 h-14 bg-teal-500 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-shield-check-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Integrity</h3>
              <p className="text-gray-600">
                We operate with transparency, honesty, and ethical practices in all our business dealings.
              </p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-white p-8 rounded-2xl border border-blue-100 hover:shadow-xl transition-all">
              <div className="w-14 h-14 bg-blue-500 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-lightbulb-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Innovation</h3>
              <p className="text-gray-600">
                We continuously explore new technologies and methodologies to deliver cutting-edge solutions.
              </p>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-white p-8 rounded-2xl border border-purple-100 hover:shadow-xl transition-all">
              <div className="w-14 h-14 bg-purple-500 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-team-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Collaboration</h3>
              <p className="text-gray-600">
                We work closely with our clients as partners, understanding their needs and goals deeply.
              </p>
            </div>

            <div className="bg-gradient-to-br from-pink-50 to-white p-8 rounded-2xl border border-pink-100 hover:shadow-xl transition-all">
              <div className="w-14 h-14 bg-pink-500 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-star-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Excellence</h3>
              <p className="text-gray-600">
                We are committed to delivering the highest quality services and exceeding expectations.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose <span className="text-teal-500">OMNET IT SYSTEM</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              What sets us apart in the competitive IT services landscape
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all">
              <div className="w-14 h-14 bg-gradient-to-br from-teal-500 to-blue-500 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-24-hours-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">24×7 Support</h3>
              <p className="text-gray-600">
                Round-the-clock monitoring and support to ensure your systems are always running optimally.
              </p>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all">
              <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-user-star-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Expert Team</h3>
              <p className="text-gray-600">
                Certified professionals with deep expertise across multiple technology domains and platforms.
              </p>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all">
              <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-teal-500 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-price-tag-3-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Cost-Effective</h3>
              <p className="text-gray-600">
                Competitive pricing models that deliver maximum value without compromising on quality.
              </p>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all">
              <div className="w-14 h-14 bg-gradient-to-br from-pink-500 to-purple-500 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-shield-star-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Security First</h3>
              <p className="text-gray-600">
                Advanced security measures and compliance standards to protect your critical business data.
              </p>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all">
              <div className="w-14 h-14 bg-gradient-to-br from-teal-500 to-purple-500 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-line-chart-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Scalable Solutions</h3>
              <p className="text-gray-600">
                Flexible infrastructure that grows with your business needs and adapts to changing requirements.
              </p>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all">
              <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-pink-500 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-customer-service-2-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Proactive Approach</h3>
              <p className="text-gray-600">
                We identify and resolve potential issues before they impact your business operations.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-20 bg-gradient-to-br from-teal-500 via-teal-600 to-blue-600 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/10 to-black/20"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Our Impact in <span className="text-teal-100">Numbers</span>
            </h2>
            <p className="text-lg text-white/90 max-w-3xl mx-auto">
              Delivering measurable results and building lasting partnerships
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-5xl font-bold text-white mb-2">500+</div>
              <div className="text-lg text-white/90">Happy Clients</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-white mb-2">1000+</div>
              <div className="text-lg text-white/90">Projects Completed</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-white mb-2">24×7</div>
              <div className="text-lg text-white/90">Support Available</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-white mb-2">99.9%</div>
              <div className="text-lg text-white/90">Uptime Guarantee</div>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Meet Our <span className="text-teal-500">Leadership Team</span>
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Experienced professionals dedicated to your success
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center group">
              <div className="relative mb-6 overflow-hidden rounded-2xl">
                <img
                  src="https://readdy.ai/api/search-image?query=professional%20Indian%20male%20IT%20executive%20in%20formal%20business%20attire%2C%20confident%20leadership%20portrait%20with%20modern%20office%20background%2C%20corporate%20headshot%20style%20photography%20with%20natural%20lighting&width=400&height=500&seq=team-ceo-1&orientation=portrait"
                  alt="CEO"
                  className="w-full h-96 object-cover object-top group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Rajesh Kumar</h3>
              <p className="text-teal-600 font-semibold mb-3">Chief Executive Officer</p>
              <p className="text-gray-600">
                15+ years of experience in IT services and digital transformation
              </p>
            </div>

            <div className="text-center group">
              <div className="relative mb-6 overflow-hidden rounded-2xl">
                <img
                  src="https://readdy.ai/api/search-image?query=professional%20Indian%20female%20technology%20director%20in%20business%20formal%20attire%2C%20confident%20executive%20portrait%20with%20modern%20tech%20office%20background%2C%20corporate%20headshot%20style%20with%20professional%20lighting&width=400&height=500&seq=team-cto-1&orientation=portrait"
                  alt="CTO"
                  className="w-full h-96 object-cover object-top group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Priya Sharma</h3>
              <p className="text-teal-600 font-semibold mb-3">Chief Technology Officer</p>
              <p className="text-gray-600">
                Expert in cloud architecture and enterprise solutions
              </p>
            </div>

            <div className="text-center group">
              <div className="relative mb-6 overflow-hidden rounded-2xl">
                <img
                  src="https://readdy.ai/api/search-image?query=professional%20Indian%20male%20operations%20director%20in%20business%20suit%2C%20confident%20management%20portrait%20with%20modern%20corporate%20office%20background%2C%20executive%20headshot%20style%20with%20professional%20studio%20lighting&width=400&height=500&seq=team-coo-1&orientation=portrait"
                  alt="COO"
                  className="w-full h-96 object-cover object-top group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Amit Patel</h3>
              <p className="text-teal-600 font-semibold mb-3">Chief Operations Officer</p>
              <p className="text-gray-600">
                Specialist in service delivery and operational excellence
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Ready to Transform Your <span className="text-teal-500">IT Infrastructure?</span>
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            Let's discuss how OMNET IT SYSTEM can help your business achieve its technology goals
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/contact"
              className="px-8 py-4 bg-teal-500 text-white font-semibold rounded-lg hover:bg-teal-600 transition-all shadow-lg hover:shadow-xl whitespace-nowrap cursor-pointer"
            >
              Get in Touch
            </a>
            <a
              href="tel:+919717270865"
              className="px-8 py-4 bg-white text-teal-600 font-semibold rounded-lg border-2 border-teal-500 hover:bg-teal-50 transition-all whitespace-nowrap cursor-pointer"
            >
              Call Us Now
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
