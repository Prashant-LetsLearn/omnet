import { useState } from 'react';

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'CEO, TechCorp Solutions',
      image: 'https://readdy.ai/api/search-image?query=professional%20business%20woman%20executive%20smiling%20portrait%20in%20modern%20office%20corporate%20headshot%20clean%20white%20background&width=100&height=100&seq=test1&orientation=squarish',
      rating: 5,
      text: 'I\'ve worked with many IT service providers over the years, but none compare to the level of expertise and dedication shown by this team. They transformed our entire IT infrastructure and helped us achieve unprecedented growth. Their proactive approach and 24/7 support have been invaluable to our operations.'
    },
    {
      name: 'Michael Chen',
      role: 'CTO, Digital Innovations Inc',
      image: 'https://readdy.ai/api/search-image?query=professional%20business%20man%20executive%20smiling%20portrait%20in%20modern%20office%20corporate%20headshot%20clean%20white%20background&width=100&height=100&seq=test2&orientation=squarish',
      rating: 5,
      text: 'Outstanding service and exceptional results! The team\'s deep technical knowledge and commitment to our success has been remarkable. They delivered our project ahead of schedule and exceeded all expectations. I highly recommend their services to any organization looking for reliable IT solutions.'
    },
    {
      name: 'Emily Rodriguez',
      role: 'Director of Operations, Global Enterprises',
      image: 'https://readdy.ai/api/search-image?query=professional%20business%20woman%20executive%20smiling%20portrait%20in%20modern%20office%20corporate%20headshot%20clean%20white%20background&width=100&height=100&seq=test3&orientation=squarish',
      rating: 5,
      text: 'The level of professionalism and technical expertise is unmatched. They took time to understand our unique challenges and delivered customized solutions that perfectly fit our needs. Their ongoing support and maintenance services have been flawless. A true partner in our digital transformation journey.'
    }
  ];

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-teal-500 font-semibold text-sm uppercase tracking-wider">Testimonials</span>
          <h2 className="text-4xl font-bold text-gray-900 mt-3 mb-4">
            Here's What Our Customers Have Said
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Don't just take our word for it - hear from our satisfied clients about their experience working with us
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12 relative">
            <div className="flex items-start space-x-6 mb-6">
              <div className="w-20 h-20 rounded-full overflow-hidden flex-shrink-0">
                <img 
                  src={testimonials[currentIndex].image}
                  alt={testimonials[currentIndex].name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-1 mb-2">
                  {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                    <i key={i} className="ri-star-fill text-yellow-400 text-lg"></i>
                  ))}
                </div>
                <h4 className="text-xl font-bold text-gray-900">{testimonials[currentIndex].name}</h4>
                <p className="text-gray-500 text-sm">{testimonials[currentIndex].role}</p>
              </div>
            </div>

            <div className="relative">
              <i className="ri-double-quotes-l text-6xl text-teal-100 absolute -top-4 -left-2"></i>
              <p className="text-gray-700 text-lg leading-relaxed relative z-10 pl-8">
                {testimonials[currentIndex].text}
              </p>
            </div>

            <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-100">
              <div className="flex space-x-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-2.5 h-2.5 rounded-full transition-all ${
                      index === currentIndex ? 'bg-teal-500 w-8' : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>

              <div className="flex space-x-2">
                <button
                  onClick={prevTestimonial}
                  className="w-10 h-10 rounded-full bg-gray-100 hover:bg-teal-500 hover:text-white transition-colors flex items-center justify-center"
                >
                  <i className="ri-arrow-left-s-line text-xl"></i>
                </button>
                <button
                  onClick={nextTestimonial}
                  className="w-10 h-10 rounded-full bg-gray-100 hover:bg-teal-500 hover:text-white transition-colors flex items-center justify-center"
                >
                  <i className="ri-arrow-right-s-line text-xl"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
