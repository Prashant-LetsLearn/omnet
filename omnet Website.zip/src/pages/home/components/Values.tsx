
export default function Values() {
  const securityFeatures = [
    {
      icon: 'ri-shield-keyhole-line',
      title: 'Security Policy Design',
      description: 'Comprehensive security frameworks and access controls'
    },
    {
      icon: 'ri-bug-line',
      title: 'Vulnerability Management',
      description: 'Proactive threat detection and incident response'
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Endpoint Security',
      description: 'CrowdStrike, SentinelOne, Defender, Seqrite'
    },
    {
      icon: 'ri-file-shield-2-line',
      title: 'Compliance Support',
      description: 'ISO 27001, NIST, GDPR, HIPAA alignment'
    }
  ];

  const technologies = [
    { category: 'Cloud', items: 'AWS, Azure, GCP, Microsoft 365, Google Workspace' },
    { category: 'Identity', items: 'JumpCloud, Entra ID, AD, SSO, MFA, Zero Trust' },
    { category: 'Cybersecurity', items: 'CrowdStrike, SentinelOne, Defender, Fortinet' },
    { category: 'Device Mgmt', items: 'Intune, Workspace ONE, ChromeOS' },
    { category: 'ITSM', items: 'ServiceNow, Freshservice, ManageEngine' },
    { category: 'Backup & DR', items: 'Veeam, Commvault, NAS, Cloud DR' },
    { category: 'Virtualization', items: 'VMware vSphere, Hyper-V' },
    { category: 'Automation', items: 'PowerShell, Terraform, DevOps tools' }
  ];

  const missionValues = [
    {
      icon: 'ri-shield-star-line',
      title: 'Security First Delivery',
      description: 'Every solution built with security at its core'
    },
    {
      icon: 'ri-rocket-line',
      title: 'Proactive Excellence',
      description: 'Anticipating needs before they become issues'
    },
    {
      icon: 'ri-team-line',
      title: 'Strategic Partnerships',
      description: 'Long-term relationships built on trust'
    },
    {
      icon: 'ri-lightbulb-flash-line',
      title: 'Innovation & Automation',
      description: 'Continuous improvement through technology'
    }
  ];

  return (
    <>
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-teal-50 to-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Security & Compliance
            </h2>
            <p className="text-xl text-gray-600">
              Enterprise-grade protection and regulatory alignment
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {securityFeatures.map((feature, index) => (
              <div 
                key={index}
                className="bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all"
              >
                <div className="w-14 h-14 bg-teal-500 rounded-xl flex items-center justify-center mb-4">
                  <i className={`${feature.icon} text-white text-2xl`}></i>
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-gray-600">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Technology Expertise
            </h2>
            <p className="text-xl text-gray-600">
              Industry-leading platforms and tools
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {technologies.map((tech, index) => (
              <div 
                key={index}
                className="bg-gradient-to-br from-gray-50 to-white p-6 rounded-xl border border-gray-200 hover:border-teal-300 transition-all"
              >
                <h3 className="text-lg font-bold text-teal-600 mb-3">
                  {tech.category}
                </h3>
                <p className="text-sm text-gray-700 leading-relaxed">
                  {tech.items}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">
              Our Mission & Values
            </h2>
            <p className="text-xl text-gray-300 max-w-4xl mx-auto">
              Deliver secure, reliable, and business-aligned IT services that reduce risk and enable sustainable growth.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {missionValues.map((value, index) => (
              <div 
                key={index}
                className="bg-white/10 backdrop-blur-sm p-6 rounded-2xl hover:bg-white/20 transition-all"
              >
                <div className="w-14 h-14 bg-teal-500 rounded-xl flex items-center justify-center mb-4">
                  <i className={`${value.icon} text-white text-2xl`}></i>
                </div>
                <h3 className="text-lg font-bold mb-2">
                  {value.title}
                </h3>
                <p className="text-sm text-gray-300">
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
