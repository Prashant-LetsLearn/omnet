
export default function CTA() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-teal-600 to-teal-700">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl font-bold text-white mb-6">
          Let's Strengthen Your IT Foundation
        </h2>
        <p className="text-xl text-white/90 mb-8 leading-relaxed">
          Partner with OMNET IT SYSTEM for secure, reliable, and business-aligned IT services that reduce risk and enable sustainable growth.
        </p>
        
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          <button className="px-8 py-4 bg-white text-teal-600 rounded-full hover:bg-gray-100 transition-all shadow-lg hover:shadow-xl font-semibold whitespace-nowrap">
            Schedule Free Consultation
          </button>
          <button className="px-8 py-4 bg-teal-800 text-white rounded-full hover:bg-teal-900 transition-all border-2 border-white/20 font-semibold whitespace-nowrap">
            View Our Services
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-8 pt-8 border-t border-white/20">
          <div className="flex flex-col items-center space-y-2">
            <i className="ri-map-pin-line text-white text-3xl"></i>
            <p className="text-white/90 text-sm">
              Unit No. 99, Gyan Khand III<br />
              Indirapuram, Ghaziabad, India
            </p>
          </div>
          <div className="flex flex-col items-center space-y-2">
            <i className="ri-phone-line text-white text-3xl"></i>
            <p className="text-white/90 text-sm">
              +91 97172 70865<br />
              <span className="text-xs">24×7 Support Available</span>
            </p>
          </div>
          <div className="flex flex-col items-center space-y-2">
            <i className="ri-mail-line text-white text-3xl"></i>
            <p className="text-white/90 text-sm">
              hello@omnetitsystem.com<br />
              <span className="text-xs">Quick Response Guaranteed</span>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
