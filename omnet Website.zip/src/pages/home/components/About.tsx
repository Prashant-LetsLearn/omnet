
export default function About() {
  const features = [
    {
      icon: 'ri-24-hours-line',
      title: '24×7 Managed Services',
      description: 'Proactive monitoring and rapid incident resolution to minimize downtime and ensure business continuity.'
    },
    {
      icon: 'ri-file-list-3-line',
      title: 'SLA-Driven Support',
      description: 'ITIL-aligned service delivery with defined response times across ticketing, email, and call-based support.'
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Enterprise-Grade Security',
      description: 'Compliance-ready security frameworks aligned with ISO 27001, NIST, GDPR, and HIPAA standards.'
    },
    {
      icon: 'ri-line-chart-line',
      title: 'Cost & Performance Optimization',
      description: 'Strategic infrastructure and cloud optimization focused on maximizing ROI and operational efficiency.'
    },
    {
      icon: 'ri-medal-line',
      title: 'Certified Technology Experts',
      description: 'Experienced professionals with proven expertise across cloud platforms, cybersecurity, and IT infrastructure.'
    },
    {
      icon: 'ri-settings-3-line',
      title: 'End-to-End Service Delivery',
      description: 'Complete lifecycle ownership—from consulting and deployment to migration, optimization, and ongoing support.'
    }
  ];

  return (
    <section className="py-20 bg-white" id="about">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Why Choose OMNET IT SYSTEM
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Your Trusted IT Partner
          </p>
          <p className="text-lg text-gray-600 max-w-4xl mx-auto mt-4">
            We operate as an extension of your IT team, delivering secure, resilient, and high-performance IT environments—so your business can scale with confidence and focus on growth.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-gradient-to-br from-teal-50 to-white p-8 rounded-2xl hover:shadow-xl transition-all duration-300 border border-teal-100"
            >
              <div className="w-14 h-14 bg-teal-500 rounded-xl flex items-center justify-center mb-6">
                <i className={`${feature.icon} text-white text-2xl`}></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                {feature.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
