
export default function Services() {
  const coreServices = [
    {
      icon: 'ri-brain-line',
      title: 'Artificial Intelligence',
      description: 'GenAI strategy & implementation, AI infrastructure design & optimization, custom AI application development, and AI security & monitoring.',
      features: ['GenAI Strategy', 'AI Infrastructure', 'Custom AI Apps', 'AI Security']
    },
    {
      icon: 'ri-cloud-line',
      title: 'Cloud Solutions',
      description: 'AWS, Azure, GCP migration & management, hybrid & multi-cloud architecture, cloud security, governance & compliance.',
      features: ['Cloud Migration', 'Multi-Cloud', 'Security & Compliance', 'Cost Optimization']
    },
    {
      icon: 'ri-database-2-line',
      title: 'Data Management',
      description: 'Enterprise data warehousing, data migration & lake modernization, governance, security & compliance, analytics & BI.',
      features: ['Data Warehousing', 'Migration', 'Governance', 'Analytics & BI']
    },
    {
      icon: 'ri-computer-line',
      title: 'Digital Workplace',
      description: 'Google Workspace & Microsoft 365, endpoint & device management, workflow automation & collaboration tools.',
      features: ['M365 & Workspace', 'Device Management', 'Automation', 'User Training']
    },
    {
      icon: 'ri-code-s-slash-line',
      title: 'Application Development',
      description: 'Custom web & mobile applications, DevOps & automation, application modernization, performance & security optimization.',
      features: ['Custom Apps', 'DevOps', 'Modernization', 'Optimization']
    },
    {
      icon: 'ri-server-line',
      title: 'Infrastructure Management',
      description: 'Windows Server & virtualization, network administration, backup, DR & business continuity, capacity planning.',
      features: ['Server Management', 'Networking', 'Backup & DR', 'Monitoring']
    }
  ];

  const extendedServices = [
    { icon: 'ri-lightbulb-line', title: 'IT Consulting', desc: 'Technology roadmap & vendor selection' },
    { icon: 'ri-customer-service-2-line', title: 'Technical Support', desc: 'L1–L3 helpdesk support' },
    { icon: 'ri-tools-line', title: 'Computer Repair', desc: 'Desktop, laptop & server maintenance' },
    { icon: 'ri-router-line', title: 'Networking', desc: 'Design, cabling & troubleshooting' },
    { icon: 'ri-home-wifi-line', title: 'Home Networking', desc: 'Secure remote work setups' },
    { icon: 'ri-hard-drive-2-line', title: 'Data Recovery', desc: 'RAID & backup restoration' }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Our Core Services
          </h2>
          <p className="text-xl text-gray-600">
            Comprehensive IT Solutions for Modern Enterprises
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {coreServices.map((service, index) => (
            <div 
              key={index}
              className="bg-white p-8 rounded-2xl hover:shadow-2xl transition-all duration-300 border border-gray-100 group"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-teal-500 to-teal-600 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <i className={`${service.icon} text-white text-3xl`}></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">
                {service.title}
              </h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                {service.description}
              </p>
              <div className="flex flex-wrap gap-2">
                {service.features.map((feature, idx) => (
                  <span 
                    key={idx}
                    className="px-3 py-1 bg-teal-50 text-teal-700 rounded-full text-sm"
                  >
                    {feature}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <h3 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            Extended IT Services
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {extendedServices.map((service, index) => (
              <div 
                key={index}
                className="flex items-start space-x-4 p-4 rounded-xl hover:bg-teal-50 transition-colors"
              >
                <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <i className={`${service.icon} text-teal-600 text-xl`}></i>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-1">{service.title}</h4>
                  <p className="text-sm text-gray-600">{service.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
