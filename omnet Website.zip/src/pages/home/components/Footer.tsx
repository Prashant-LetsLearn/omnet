import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 bg-teal-500 rounded-lg flex items-center justify-center">
                <i className="ri-code-s-slash-line text-white text-xl"></i>
              </div>
              <span className="text-xl font-bold">OMNET IT SYSTEM</span>
            </div>
            <p className="text-white/80 mb-6 leading-relaxed">
              Trusted enterprise IT solutions and managed services partner helping organizations build secure, scalable, and high-performing IT environments.
            </p>
            <div className="flex space-x-3">
              <a href="#" className="w-10 h-10 bg-white/10 hover:bg-teal-500 rounded-full flex items-center justify-center transition-colors">
                <i className="ri-facebook-fill"></i>
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 hover:bg-teal-500 rounded-full flex items-center justify-center transition-colors">
                <i className="ri-twitter-fill"></i>
              </a>
              <a href="https://www.linkedin.com/company/omnet-it-system/" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-white/10 hover:bg-teal-500 rounded-full flex items-center justify-center transition-colors">
                <i className="ri-linkedin-fill"></i>
              </a>
              <a href="#" className="w-10 h-10 bg-white/10 hover:bg-teal-500 rounded-full flex items-center justify-center transition-colors">
                <i className="ri-instagram-fill"></i>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6">Core Services</h3>
            <ul className="space-y-3">
              <li><Link to="/services/ai" className="text-white/80 hover:text-teal-400 transition-colors">Artificial Intelligence</Link></li>
              <li><Link to="/services/cloud" className="text-white/80 hover:text-teal-400 transition-colors">Cloud Solutions</Link></li>
              <li><Link to="/services/data" className="text-white/80 hover:text-teal-400 transition-colors">Data Management</Link></li>
              <li><Link to="/services/workplace" className="text-white/80 hover:text-teal-400 transition-colors">Digital Workplace</Link></li>
              <li><Link to="/services/development" className="text-white/80 hover:text-teal-400 transition-colors">Application Development</Link></li>
              <li><Link to="/services/infrastructure" className="text-white/80 hover:text-teal-400 transition-colors">Infrastructure Management</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6">Company</h3>
            <ul className="space-y-3">
              <li><Link to="/about" className="text-white/80 hover:text-teal-400 transition-colors">About Us</Link></li>
              <li><Link to="/industries" className="text-white/80 hover:text-teal-400 transition-colors">Industries</Link></li>
              <li><Link to="/security" className="text-white/80 hover:text-teal-400 transition-colors">Security & Compliance</Link></li>
              <li><Link to="/careers" className="text-white/80 hover:text-teal-400 transition-colors">Careers</Link></li>
              <li><Link to="/partners" className="text-white/80 hover:text-teal-400 transition-colors">Technology Partners</Link></li>
              <li><Link to="/contact" className="text-white/80 hover:text-teal-400 transition-colors">Contact Us</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6">Contact Info</h3>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3">
                <i className="ri-map-pin-line text-teal-400 text-xl mt-1"></i>
                <span className="text-white/80">Unit No. 99, Gyan Khand III, Indirapuram, Ghaziabad, India</span>
              </li>
              <li className="flex items-start space-x-3">
                <i className="ri-phone-line text-teal-400 text-xl"></i>
                <span className="text-white/80">+91 97172 70865</span>
              </li>
              <li className="flex items-start space-x-3">
                <i className="ri-mail-line text-teal-400 text-xl"></i>
                <span className="text-white/80">hello@omnetitsystem.com</span>
              </li>
              <li className="flex items-start space-x-3">
                <i className="ri-customer-service-2-line text-teal-400 text-xl"></i>
                <span className="text-white/80">24×7 Support Available</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-white/60 text-sm">
              © 2025 OMNET IT SYSTEM. All rights reserved.
            </p>
            <div className="flex items-center space-x-6">
              <Link to="/privacy" className="text-white/60 hover:text-teal-400 text-sm transition-colors">Privacy Policy</Link>
              <Link to="/terms" className="text-white/60 hover:text-teal-400 text-sm transition-colors">Terms of Service</Link>
              <a href="https://readdy.ai/?ref=logo" target="_blank" rel="noopener noreferrer" className="text-white/60 hover:text-teal-400 text-sm transition-colors">Powered by Readdy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
