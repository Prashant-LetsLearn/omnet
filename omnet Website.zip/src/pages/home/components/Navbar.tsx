import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleDropdown = (menu: string) => {
    setOpenDropdown(openDropdown === menu ? null : menu);
  };

  return (
    <>
      {/* Top Contact Bar */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-end items-center h-12 space-x-6 text-sm">
            <a href="tel:+919717270865" className="flex items-center space-x-2 text-gray-600 hover:text-teal-500 transition-colors cursor-pointer">
              <i className="ri-phone-line text-teal-500"></i>
              <span>+91 9717270865</span>
            </a>
            <a href="tel:+911205223376" className="flex items-center space-x-2 text-gray-600 hover:text-teal-500 transition-colors cursor-pointer">
              <i className="ri-phone-line text-teal-500"></i>
              <span>+91 120 5223376</span>
            </a>
            <a href="mailto:hello@omnetitsystem.com" className="flex items-center space-x-2 text-gray-600 hover:text-teal-500 transition-colors cursor-pointer">
              <i className="ri-mail-line text-teal-500"></i>
              <span>hello@omnetitsystem.com</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <nav className={`fixed w-full top-12 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-lg' : 'bg-white'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-teal-500 rounded-lg flex items-center justify-center">
                <i className="ri-code-s-slash-line text-white text-xl"></i>
              </div>
              <span className="text-xl font-bold text-gray-900">OMNET IT SYSTEM</span>
            </Link>

            <div className="hidden lg:flex items-center space-x-1">
              {/* Microsoft Dropdown */}
              <div className="relative group">
                <button 
                  className="px-4 py-2 font-medium text-gray-700 hover:text-teal-500 transition-colors flex items-center space-x-1 cursor-pointer whitespace-nowrap"
                  onMouseEnter={() => setOpenDropdown('microsoft')}
                >
                  <span>Microsoft</span>
                  <i className="ri-arrow-down-s-line text-sm"></i>
                </button>
                {openDropdown === 'microsoft' && (
                  <div 
                    className="absolute top-full left-0 mt-0 w-56 bg-white shadow-lg rounded-lg py-2 z-50"
                    onMouseLeave={() => setOpenDropdown(null)}
                  >
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Office 365</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Azure</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Dynamics 365</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Windows Server</a>
                  </div>
                )}
              </div>

              {/* Google Dropdown */}
              <div className="relative group">
                <button 
                  className="px-4 py-2 font-medium text-gray-700 hover:text-teal-500 transition-colors flex items-center space-x-1 cursor-pointer whitespace-nowrap"
                  onMouseEnter={() => setOpenDropdown('google')}
                >
                  <span>Google</span>
                  <i className="ri-arrow-down-s-line text-sm"></i>
                </button>
                {openDropdown === 'google' && (
                  <div 
                    className="absolute top-full left-0 mt-0 w-56 bg-white shadow-lg rounded-lg py-2 z-50"
                    onMouseLeave={() => setOpenDropdown(null)}
                  >
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Google Workspace</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">GCP</a>
                  </div>
                )}
              </div>

              {/* Adobe Dropdown */}
              <div className="relative group">
                <button 
                  className="px-4 py-2 font-medium text-gray-700 hover:text-teal-500 transition-colors flex items-center space-x-1 cursor-pointer whitespace-nowrap"
                  onMouseEnter={() => setOpenDropdown('adobe')}
                >
                  <span>Adobe</span>
                  <i className="ri-arrow-down-s-line text-sm"></i>
                </button>
                {openDropdown === 'adobe' && (
                  <div 
                    className="absolute top-full left-0 mt-0 w-56 bg-white shadow-lg rounded-lg py-2 z-50"
                    onMouseLeave={() => setOpenDropdown(null)}
                  >
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Creative Cloud</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Acrobat Pro</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Document Cloud</a>
                  </div>
                )}
              </div>

              {/* Autodesk Dropdown */}
              <div className="relative group">
                <button 
                  className="px-4 py-2 font-medium text-gray-700 hover:text-teal-500 transition-colors flex items-center space-x-1 cursor-pointer whitespace-nowrap"
                  onMouseEnter={() => setOpenDropdown('autodesk')}
                >
                  <span>Autodesk</span>
                  <i className="ri-arrow-down-s-line text-sm"></i>
                </button>
                {openDropdown === 'autodesk' && (
                  <div 
                    className="absolute top-full left-0 mt-0 w-56 bg-white shadow-lg rounded-lg py-2 z-50"
                    onMouseLeave={() => setOpenDropdown(null)}
                  >
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">AutoCAD</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Revit</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">3ds Max</a>
                  </div>
                )}
              </div>

              {/* Cloud Dropdown */}
              <div className="relative group">
                <button 
                  className="px-4 py-2 font-medium text-gray-700 hover:text-teal-500 transition-colors flex items-center space-x-1 cursor-pointer whitespace-nowrap"
                  onMouseEnter={() => setOpenDropdown('cloud')}
                >
                  <span>Cloud</span>
                  <i className="ri-arrow-down-s-line text-sm"></i>
                </button>
                {openDropdown === 'cloud' && (
                  <div 
                    className="absolute top-full left-0 mt-0 w-56 bg-white shadow-lg rounded-lg py-2 z-50"
                    onMouseLeave={() => setOpenDropdown(null)}
                  >
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Cloud Migration</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Cloud Management</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Hybrid Cloud</a>
                  </div>
                )}
              </div>

              {/* Software Dropdown */}
              <div className="relative group">
                <button 
                  className="px-4 py-2 font-medium text-gray-700 hover:text-teal-500 transition-colors flex items-center space-x-1 cursor-pointer whitespace-nowrap"
                  onMouseEnter={() => setOpenDropdown('software')}
                >
                  <span>Software</span>
                  <i className="ri-arrow-down-s-line text-sm"></i>
                </button>
                {openDropdown === 'software' && (
                  <div 
                    className="absolute top-full left-0 mt-0 w-56 bg-white shadow-lg rounded-lg py-2 z-50"
                    onMouseLeave={() => setOpenDropdown(null)}
                  >
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Enterprise Software</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Security Software</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Productivity Tools</a>
                  </div>
                )}
              </div>

              {/* Hardware Dropdown */}
              <div className="relative group">
                <button 
                  className="px-4 py-2 font-medium text-gray-700 hover:text-teal-500 transition-colors flex items-center space-x-1 cursor-pointer whitespace-nowrap"
                  onMouseEnter={() => setOpenDropdown('hardware')}
                >
                  <span>Hardware</span>
                  <i className="ri-arrow-down-s-line text-sm"></i>
                </button>
                {openDropdown === 'hardware' && (
                  <div 
                    className="absolute top-full left-0 mt-0 w-56 bg-white shadow-lg rounded-lg py-2 z-50"
                    onMouseLeave={() => setOpenDropdown(null)}
                  >
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Servers & Storage</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Networking Equipment</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Workstations</a>
                  </div>
                )}
              </div>

              {/* Managed IT Service Dropdown */}
              <div className="relative group">
                <button 
                  className="px-4 py-2 font-medium text-gray-700 hover:text-teal-500 transition-colors flex items-center space-x-1 cursor-pointer whitespace-nowrap"
                  onMouseEnter={() => setOpenDropdown('managed')}
                >
                  <span>Managed IT Service</span>
                  <i className="ri-arrow-down-s-line text-sm"></i>
                </button>
                {openDropdown === 'managed' && (
                  <div 
                    className="absolute top-full left-0 mt-0 w-56 bg-white shadow-lg rounded-lg py-2 z-50"
                    onMouseLeave={() => setOpenDropdown(null)}
                  >
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">24/7 Monitoring</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">Help Desk Support</a>
                    <a href="/services" className="block px-4 py-2 text-sm text-gray-700 hover:bg-teal-50 hover:text-teal-600 transition-colors cursor-pointer">IT Consulting</a>
                  </div>
                )}
              </div>
            </div>

            <div className="hidden lg:flex items-center space-x-4">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Search..." 
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                />
                <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
              </div>
              <Link to="/contact" className="px-6 py-2.5 bg-teal-500 text-white rounded-lg hover:bg-teal-600 transition-all shadow-md whitespace-nowrap cursor-pointer">
                Get a quote now
              </Link>
            </div>

            <button 
              className="lg:hidden text-gray-700 text-2xl cursor-pointer"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              <i className={isMobileMenuOpen ? 'ri-close-line' : 'ri-menu-line'}></i>
            </button>
          </div>
        </div>
      </nav>

      {isMobileMenuOpen && (
        <div className="lg:hidden bg-white border-t border-gray-200 shadow-lg fixed top-32 left-0 right-0 z-40">
          <div className="px-4 py-6 space-y-4">
            <a href="/services" className="block font-medium text-gray-700 hover:text-teal-500 transition-colors cursor-pointer">Microsoft</a>
            <a href="/services" className="block font-medium text-gray-700 hover:text-teal-500 transition-colors cursor-pointer">Google</a>
            <a href="/services" className="block font-medium text-gray-700 hover:text-teal-500 transition-colors cursor-pointer">Adobe</a>
            <a href="/services" className="block font-medium text-gray-700 hover:text-teal-500 transition-colors cursor-pointer">Autodesk</a>
            <a href="/services" className="block font-medium text-gray-700 hover:text-teal-500 transition-colors cursor-pointer">Cloud</a>
            <a href="/services" className="block font-medium text-gray-700 hover:text-teal-500 transition-colors cursor-pointer">Software</a>
            <a href="/services" className="block font-medium text-gray-700 hover:text-teal-500 transition-colors cursor-pointer">Hardware</a>
            <a href="/services" className="block font-medium text-gray-700 hover:text-teal-500 transition-colors cursor-pointer">Managed IT Service</a>
            <Link to="/contact" className="block px-6 py-2 bg-teal-500 text-white font-semibold rounded-lg hover:bg-teal-600 transition-all text-center whitespace-nowrap cursor-pointer">
              Get a quote now
            </Link>
          </div>
        </div>
      )}
    </>
  );
}
