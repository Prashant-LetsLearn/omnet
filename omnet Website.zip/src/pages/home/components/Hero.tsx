
import { Link } from 'react-router-dom';

export default function Hero() {
  return (
    <section className="relative pt-48 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden bg-white">
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              Transform Your Business with Enterprise IT Solutions
            </h1>
            
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Comprehensive managed IT services, cloud solutions, and technology consulting to help your business thrive in the digital age. We provide end-to-end support for Microsoft, Adobe, Autodesk, and enterprise infrastructure.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <Link to="/contact" className="px-8 py-4 bg-teal-500 text-white rounded-lg hover:bg-teal-600 transition-all shadow-lg hover:shadow-xl whitespace-nowrap cursor-pointer font-semibold">
                Get Started Today
              </Link>
              <Link to="/services" className="px-8 py-4 bg-white text-gray-700 rounded-lg hover:bg-gray-50 transition-all border-2 border-gray-300 whitespace-nowrap cursor-pointer font-semibold">
                View Our Services
              </Link>
            </div>
          </div>

          <div className="relative">
            <div className="relative z-10">
              <img 
                src="https://readdy.ai/api/search-image?query=modern%20enterprise%20IT%20infrastructure%20with%20cloud%20computing%20servers%20network%20security%20monitoring%20systems%20and%20professional%20managed%20services%20technology%20in%20sleek%20data%20center%20environment%20with%20blue%20and%20teal%20lighting&width=600&height=700&seq=hero-enterprise&orientation=portrait"
                alt="Enterprise IT Solutions"
                className="w-full h-auto rounded-2xl shadow-2xl object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
