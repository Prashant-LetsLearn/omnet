export default function Partners() {
  const partners = [
    { name: 'Microsoft', logo: 'ri-microsoft-fill' },
    { name: 'Amazon', logo: 'ri-amazon-fill' },
    { name: 'Google', logo: 'ri-google-fill' },
    { name: 'Apple', logo: 'ri-apple-fill' },
    { name: 'Meta', logo: 'ri-meta-fill' }
  ];

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <p className="text-center text-gray-500 text-sm font-medium mb-8 uppercase tracking-wider">
          Trusted by Leading Companies
        </p>
        <div className="flex flex-wrap justify-center items-center gap-12">
          {partners.map((partner, index) => (
            <div key={index} className="flex items-center justify-center opacity-60 hover:opacity-100 transition-opacity">
              <i className={`${partner.logo} text-5xl text-gray-700`}></i>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
