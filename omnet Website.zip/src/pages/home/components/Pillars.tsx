export default function Pillars() {
  const pillars = [
    {
      image: 'https://readdy.ai/api/search-image?query=cyber%20security%20digital%20shield%20protection%20network%20security%20with%20glowing%20blue%20technology%20elements%20on%20dark%20background%20modern%20abstract%20security%20concept&width=400&height=300&seq=pillar1&orientation=landscape',
      title: 'Cyber Security',
      description: 'Advanced security solutions protecting your digital infrastructure from evolving cyber threats with real-time monitoring and threat intelligence'
    },
    {
      image: 'https://readdy.ai/api/search-image?query=data%20analytics%20visualization%20dashboard%20with%20charts%20graphs%20and%20statistics%20on%20computer%20screens%20modern%20business%20intelligence%20technology%20blue%20tones&width=400&height=300&seq=pillar2&orientation=landscape',
      title: 'Data Analytics',
      description: 'Transform raw data into actionable insights with our advanced analytics platform, enabling data-driven decision making for business growth'
    },
    {
      image: 'https://readdy.ai/api/search-image?query=managed%20IT%20services%20professional%20support%20team%20working%20with%20multiple%20computer%20monitors%20in%20modern%20tech%20operations%20center%20blue%20lighting&width=400&height=300&seq=pillar3&orientation=landscape',
      title: 'Managed Services',
      description: 'Comprehensive IT management and support services ensuring optimal performance, reliability, and continuous improvement of your technology infrastructure'
    }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-teal-500 font-semibold text-sm uppercase tracking-wider">Core Expertise</span>
          <h2 className="text-4xl font-bold text-gray-900 mt-3 mb-4">
            Fingent's Four Pillars Of Influence
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Our expertise is built on four fundamental pillars that drive innovation and deliver exceptional value to our clients
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {pillars.map((pillar, index) => (
            <div 
              key={index}
              className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer"
            >
              <div className="relative h-56 overflow-hidden">
                <img 
                  src={pillar.image}
                  alt={pillar.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3">{pillar.title}</h3>
                <p className="text-gray-600 text-sm leading-relaxed mb-4">{pillar.description}</p>
                <button className="text-teal-500 font-semibold flex items-center group-hover:text-teal-600 whitespace-nowrap">
                  Learn More <i className="ri-arrow-right-line ml-2"></i>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
