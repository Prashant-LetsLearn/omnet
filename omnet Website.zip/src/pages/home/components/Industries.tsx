
export default function Industries() {
  const industries = [
    {
      icon: 'ri-computer-line',
      title: 'IT / ITES',
      description: 'Scalable infrastructure and cloud solutions for technology companies'
    },
    {
      icon: 'ri-shopping-cart-line',
      title: 'Retail',
      description: 'Omnichannel systems and secure payment infrastructure'
    },
    {
      icon: 'ri-box-3-line',
      title: 'Consumer Packaged Goods',
      description: 'Supply chain optimization and data analytics'
    },
    {
      icon: 'ri-heart-pulse-line',
      title: 'Healthcare',
      description: 'HIPAA-compliant systems and secure patient data management'
    },
    {
      icon: 'ri-building-line',
      title: 'Real Estate',
      description: 'Property management systems and digital transformation'
    },
    {
      icon: 'ri-briefcase-line',
      title: 'Professional Services',
      description: 'Collaboration tools and secure client data handling'
    },
    {
      icon: 'ri-settings-2-line',
      title: 'Manufacturing',
      description: 'Industrial IoT and production system integration'
    },
    {
      icon: 'ri-tv-line',
      title: 'Media & Communication',
      description: 'Content delivery and high-performance infrastructure'
    },
    {
      icon: 'ri-rocket-2-line',
      title: 'Startups & Growth Companies',
      description: 'Flexible IT infrastructure that scales with your business'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-white" id="industries">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Industry Solutions
          </h2>
          <p className="text-xl text-gray-600">
            Tailored IT services for performance, compliance, and scale
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {industries.map((industry, index) => (
            <div 
              key={index}
              className="group bg-gradient-to-br from-white to-teal-50 p-8 rounded-2xl border border-gray-200 hover:border-teal-400 hover:shadow-xl transition-all duration-300"
            >
              <div className="w-14 h-14 bg-teal-500 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <i className={`${industry.icon} text-white text-2xl`}></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                {industry.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {industry.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
