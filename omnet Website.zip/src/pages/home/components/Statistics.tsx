export default function Statistics() {
  const stats = [
    { number: '1982', label: 'Year Founded', suffix: '' },
    { number: '1.5', label: 'Clients Worldwide', suffix: 'k+' },
    { number: '3.9', label: 'Customer Rating', suffix: '/5' }
  ];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-cyan-400 via-teal-400 to-blue-500 relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
      </div>
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            We Develop Strategic Software Solutions For Businesses
          </h2>
          <p className="text-white/90 text-lg">
            Trusted by thousands of companies worldwide
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-5xl font-bold text-white mb-2">
                {stat.number}{stat.suffix}
              </div>
              <div className="text-white/90 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="px-8 py-3.5 bg-white text-teal-500 rounded-full hover:bg-gray-50 transition-all shadow-xl font-semibold whitespace-nowrap">
            Get A Free Quote Now
          </button>
        </div>
      </div>
    </section>
  );
}