import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import About from './components/About';
import Values from './components/Values';
import Industries from './components/Industries';
import Pillars from './components/Pillars';
import Statistics from './components/Statistics';
import CTA from './components/CTA';
import Footer from './components/Footer';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <Services />
      <About />
      <Values />
      <Industries />
      <Pillars />
      <Statistics />
      <CTA />
      <Footer />
    </div>
  );
}