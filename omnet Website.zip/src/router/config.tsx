import type { RouteObject } from "react-router-dom";
import NotFound from "../pages/NotFound";
import Home from "../pages/home/page";
import { lazy } from "react";

const Contact = lazy(() => import("../pages/contact/page"));
const Services = lazy(() => import("../pages/services/page"));
const Industries = lazy(() => import("../pages/industries/page"));
const Partners = lazy(() => import("../pages/partners/page"));
const About = lazy(() => import("../pages/about/page"));

const routes: RouteObject[] = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/contact",
    element: <Contact />,
  },
  {
    path: "/services",
    element: <Services />,
  },
  {
    path: "/industries",
    element: <Industries />,
  },
  {
    path: "/partners",
    element: <Partners />,
  },
  {
    path: "/about",
    element: <About />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
];

export default routes;
